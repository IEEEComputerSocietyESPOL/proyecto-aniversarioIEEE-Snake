module proyecto.snakeespol {
    requires javafx.controls;
    exports proyecto;
}
