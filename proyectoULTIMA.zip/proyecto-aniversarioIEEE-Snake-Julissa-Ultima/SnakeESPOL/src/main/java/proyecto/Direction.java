package proyecto;
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}